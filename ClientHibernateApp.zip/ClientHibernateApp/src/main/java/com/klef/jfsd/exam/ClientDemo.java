package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        // Create session factory
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

        // Insert records
        insertClients(factory);

        // Print all records
        printAllClients(factory);

        factory.close();
    }

    public static void insertClients(SessionFactory factory) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();

        // Create and save clients
        Client client1 = new Client();
        client1.setName("Alice");
        client1.setGender("Female");
        client1.setAge(28);
        client1.setLocation("New York");
        client1.setEmail("alice@example.com");
        client1.setMobile("1234567890");

        Client client2 = new Client();
        client2.setName("Bob");
        client2.setGender("Male");
        client2.setAge(32);
        client2.setLocation("Los Angeles");
        client2.setEmail("bob@example.com");
        client2.setMobile("0987654321");

        session.save(client1);
        session.save(client2);

        transaction.commit();
        session.close();

        System.out.println("Clients inserted successfully!");
    }

    public static void printAllClients(SessionFactory factory) {
        Session session = factory.openSession();

        // HQL Query to fetch all clients
        List<Client> clients = session.createQuery("from Client", Client.class).list();

        for (Client client : clients) {
            System.out.println("Client ID: " + client.getId());
            System.out.println("Name: " + client.getName());
            System.out.println("Gender: " + client.getGender());
            System.out.println("Age: " + client.getAge());
            System.out.println("Location: " + client.getLocation());
            System.out.println("Email: " + client.getEmail());
            System.out.println("Mobile: " + client.getMobile());
            System.out.println("----------------------------");
        }

        session.close();
    }
}
